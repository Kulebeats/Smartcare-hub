import EHRPatientBinding from "../ehr-patient-binding"

export default function Page() {
  return <EHRPatientBinding />
}
