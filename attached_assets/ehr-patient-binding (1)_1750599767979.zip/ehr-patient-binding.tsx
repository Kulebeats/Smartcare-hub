"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { PatientSearchModal } from "./components/patient-search-modal"
import { PatientRelations } from "./components/patient-relations"
import { PatientHeader } from "./components/patient-header"
import { CheckCircle } from "lucide-react"

interface Patient {
  id: string
  nrc: string
  nupn: string
  firstName: string
  lastName: string
  sex: string
  dob: string
  cellPhone: string
  motherName?: string
}

interface PatientRelation {
  id: string
  name: string
  nrc: string
  nupn: string
  sex: string
  relationType: string
  household: boolean
  tbContact: boolean
  htsIndex: boolean
  buddy: boolean
  guardian: boolean
}

export default function EHRPatientBinding() {
  const [searchModalOpen, setSearchModalOpen] = useState(false)
  const [showSuccessMessage, setShowSuccessMessage] = useState(false)
  const [relations, setRelations] = useState<PatientRelation[]>([
    {
      id: "1",
      name: "KUWANI BANDA",
      nrc: "358916/61/1",
      nupn: "8ADB0225-A265-44",
      sex: "Male",
      relationType: "Brother",
      household: false,
      tbContact: false,
      htsIndex: false,
      buddy: false,
      guardian: false,
    },
  ])

  const currentPatient = {
    name: "KUW BANDA",
    dateOfBirth: "6-Mar-1988 (37Y)",
    sex: "Male",
    cellphone: "0000 0000000000",
    nupn: "3030-310-01285-6",
    nrc: "000000/00/0",
  }

  const handlePatientBind = (patient: Patient, relationshipType: string, attributes: string[]) => {
    const newRelation: PatientRelation = {
      id: Date.now().toString(),
      name: `${patient.firstName} ${patient.lastName}`,
      nrc: patient.nrc,
      nupn: patient.nupn,
      sex: patient.sex,
      relationType: relationshipType,
      household: attributes.includes("Household"),
      tbContact: attributes.includes("TB Contact"),
      htsIndex: attributes.includes("HTS Index"),
      buddy: attributes.includes("Buddy"),
      guardian: attributes.includes("Guardian"),
    }

    setRelations((prev) => [...prev, newRelation])
    setShowSuccessMessage(true)

    // Hide success message after 3 seconds
    setTimeout(() => {
      setShowSuccessMessage(false)
    }, 3000)
  }

  const handleUpdateRelation = (relationId: string) => {
    // In a real app, this would open an edit modal
    console.log("Update relation:", relationId)
  }

  const handleUnbindRelation = (relationId: string) => {
    setRelations((prev) => prev.filter((relation) => relation.id !== relationId))
  }

  return (
    <div className="min-h-screen bg-white">
      {/* Success Message */}
      {showSuccessMessage && (
        <div className="max-w-7xl mx-auto px-4 py-2">
          <div className="bg-green-50 border border-green-200 text-green-800 px-4 py-3 rounded flex items-center gap-2">
            <CheckCircle className="h-5 w-5 text-green-600" />
            Patient bind has been updated successfully.
          </div>
        </div>
      )}

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-4 py-6 space-y-6">
        {/* Patient Header */}
        <PatientHeader patient={currentPatient} />

        {/* Patient Relations Section */}
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle>Patient Relations</CardTitle>
              <Button onClick={() => setSearchModalOpen(true)} className="bg-blue-500 hover:bg-blue-600 text-white">
                Add Relation
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            {relations.length > 0 ? (
              <PatientRelations
                relations={relations}
                onUpdateRelation={handleUpdateRelation}
                onUnbindRelation={handleUnbindRelation}
              />
            ) : (
              <div className="text-center py-8 text-gray-500">
                No patient relations found. Click "Add Relation" to bind patients.
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Search Modal */}
      <PatientSearchModal open={searchModalOpen} onOpenChange={setSearchModalOpen} onPatientBind={handlePatientBind} />
    </div>
  )
}
