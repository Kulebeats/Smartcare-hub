"use client"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"

interface PatientRelation {
  id: string
  name: string
  nrc: string
  nupn: string
  sex: string
  relationType: string
  household: boolean
  tbContact: boolean
  htsIndex: boolean
  buddy: boolean
  guardian: boolean
}

interface PatientRelationsProps {
  relations: PatientRelation[]
  onUpdateRelation: (relationId: string) => void
  onUnbindRelation: (relationId: string) => void
}

export function PatientRelations({ relations, onUpdateRelation, onUnbindRelation }: PatientRelationsProps) {
  return (
    <div className="space-y-4">
      {relations.map((relation) => (
        <Card key={relation.id} className="bg-gray-100 border-gray-200">
          <CardContent className="p-4">
            <div className="grid grid-cols-12 gap-4 items-center">
              <div className="col-span-2">
                <div className="font-semibold text-blue-600">{relation.name}</div>
                <div className="text-sm text-gray-600">
                  <div>NRC: {relation.nrc}</div>
                </div>
              </div>

              <div className="col-span-2">
                <div className="text-sm">
                  <div>Sex: {relation.sex}</div>
                  <div>NUPN: {relation.nupn}</div>
                </div>
              </div>

              <div className="col-span-2">
                <div className="text-sm">
                  <div>
                    Relation Type: <span className="font-medium">{relation.relationType}</span>
                  </div>
                  <div>HTS Index: {relation.htsIndex ? "Yes" : "No"}</div>
                </div>
              </div>

              <div className="col-span-2">
                <div className="text-sm">
                  <div>Household: {relation.household ? "Yes" : "No"}</div>
                  <div>Guardian: {relation.guardian ? "Yes" : "No"}</div>
                </div>
              </div>

              <div className="col-span-2">
                <div className="text-sm">
                  <div>TB Contact: {relation.tbContact ? "Yes" : "No"}</div>
                  <div>Buddy: {relation.buddy ? "Yes" : "No"}</div>
                </div>
              </div>

              <div className="col-span-2 flex gap-2">
                <Button
                  size="sm"
                  className="bg-blue-500 hover:bg-blue-600 text-white"
                  onClick={() => onUpdateRelation(relation.id)}
                >
                  Update
                </Button>
                <Button
                  size="sm"
                  className="bg-red-500 hover:bg-red-600 text-white"
                  onClick={() => onUnbindRelation(relation.id)}
                >
                  Unbind
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  )
}
