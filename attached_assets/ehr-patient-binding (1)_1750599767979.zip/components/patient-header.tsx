import { Calendar, Phone, User, Hash, CreditCard } from "lucide-react"
import { Card, CardContent } from "@/components/ui/card"

interface PatientHeaderProps {
  patient: {
    name: string
    dateOfBirth: string
    sex: string
    cellphone: string
    nupn: string
    nrc: string
  }
}

export function PatientHeader({ patient }: PatientHeaderProps) {
  return (
    <Card className="bg-blue-50 border-blue-100">
      <CardContent className="p-6">
        <div className="grid grid-cols-5 gap-6">
          <div>
            <h2 className="text-2xl font-bold text-gray-900 mb-4">{patient.name}</h2>
          </div>

          <div className="space-y-2">
            <div className="text-sm font-medium text-gray-700">Date of Birth</div>
            <div className="flex items-center gap-2">
              <Calendar className="h-4 w-4 text-gray-500" />
              <span className="text-sm">{patient.dateOfBirth}</span>
            </div>
          </div>

          <div className="space-y-2">
            <div className="text-sm font-medium text-gray-700">Sex</div>
            <div className="flex items-center gap-2">
              <User className="h-4 w-4 text-gray-500" />
              <span className="text-sm">{patient.sex}</span>
            </div>
          </div>

          <div className="space-y-2">
            <div className="text-sm font-medium text-gray-700">Cellphone</div>
            <div className="flex items-center gap-2">
              <Phone className="h-4 w-4 text-gray-500" />
              <span className="text-sm">{patient.cellphone}</span>
            </div>
          </div>

          <div className="space-y-2">
            <div className="text-sm font-medium text-gray-700">NUPN</div>
            <div className="flex items-center gap-2">
              <Hash className="h-4 w-4 text-gray-500" />
              <span className="text-sm">{patient.nupn}</span>
            </div>
          </div>
        </div>

        <div className="mt-4 pt-4 border-t border-blue-100">
          <div className="flex items-center gap-2">
            <CreditCard className="h-4 w-4 text-gray-500" />
            <span className="text-sm font-medium text-gray-600">NRC:</span>
            <span className="text-sm">{patient.nrc}</span>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
